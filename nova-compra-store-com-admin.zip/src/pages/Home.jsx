import React from 'react';
export default function Home() {
  return (
    <div>
      <h1>Bem-vindo à NovaCompra Store 🛒</h1>
      <p>Essa é a página da loja.</p>
    </div>
  );
}
