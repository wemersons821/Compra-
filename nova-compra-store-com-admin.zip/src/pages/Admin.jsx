import React from 'react';
export default function Admin() {
  return (
    <div>
      <h1>Painel de Administração 🔧</h1>
      <p>Aqui você poderá gerenciar sua loja.</p>
    </div>
  );
}
